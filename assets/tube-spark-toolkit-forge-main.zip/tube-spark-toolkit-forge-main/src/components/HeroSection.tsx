
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, CheckCircle, ArrowRight } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="pt-32 pb-20 px-6">
      <div className="container mx-auto text-center">
        <Badge className="mb-6 bg-purple-500/20 text-purple-300 border-purple-500/30 hover:bg-purple-500/30">
          Open Source YouTube Toolkit
        </Badge>
        
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
          YouTube Toolkit
          <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent block mt-2">
            Editor's Best Friend
          </span>
        </h1>
        
        <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
          Your all-in-one solution for downloading YouTube content. Download songs, videos, 
          extract metadata, and save entire playlists with our free, open-source toolkit.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <Button size="lg" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-lg px-8 py-6">
            <Download className="mr-2 h-5 w-5" /> Download for Windows
          </Button>
          <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10 text-lg px-8 py-6" disabled>
            <Download className="mr-2 h-5 w-5" /> Mac Version Coming Soon
          </Button>
        </div>

        {/* App Preview */}
        <div className="relative max-w-5xl mx-auto">
          <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 backdrop-blur-lg rounded-3xl p-4 border border-white/10 shadow-2xl">
            <div className="relative">
              <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-black/40 backdrop-blur-md rounded-t-xl px-6 py-2 border border-white/10">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
              </div>
              <div className="bg-black/40 rounded-2xl overflow-hidden">
                <img 
                  src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIwMCIgaGVpZ2h0PSI2MDAiIHZpZXdCb3g9IjAgMCAxMjAwIDYwMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTIwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IiMxMTE4MjciLz48cmVjdCB4PSIxMDAiIHk9IjgwIiB3aWR0aD0iMjAwIiBoZWlnaHQ9IjE1MCIgcng9IjgiIGZpbGw9IiMyQTBBNEEiLz48cmVjdCB4PSIzNTAiIHk9IjgwIiB3aWR0aD0iNDUwIiBoZWlnaHQ9IjE1MCIgcng9IjgiIGZpbGw9IiMxRDFFMzAiLz48cmVjdCB4PSI4NTAiIHk9IjgwIiB3aWR0aD0iMjUwIiBoZWlnaHQ9IjE1MCIgcng9IjgiIGZpbGw9IiMxRDFFMzAiLz48cmVjdCB4PSI4NzAiIHk9IjExMCIgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiM0ODNENzAiLz48cmVjdCB4PSI4NzAiIHk9IjE1MCIgd2lkdGg9IjE2MCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiM0ODNENzAiLz48cmVjdCB4PSI4NzAiIHk9IjE5MCIgd2lkdGg9IjE4MCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiM0ODNENzAiLz48cmVjdCB4PSIzNzAiIHk9IjEwMCIgd2lkdGg9IjQwMCIgaGVpZ2h0PSIzMCIgcng9IjQiIGZpbGw9IiM0ODNENzAiLz48cmVjdCB4PSIzNzAiIHk9IjE2MCIgd2lkdGg9IjMwMCIgaGVpZ2h0PSIzMCIgcng9IjQiIGZpbGw9IiM0ODNENzAiLz48cmVjdCB4PSIxMjAiIHk9IjEyMCIgd2lkdGg9IjE2MCIgaGVpZ2h0PSI4MCIgcng9IjQiIGZpbGw9IiM2QTRCQkUiLz48cmVjdCB4PSIxMDAiIHk9IjI2MCIgd2lkdGg9IjEwMDAiIGhlaWdodD0iMjYwIiByeD0iOCIgZmlsbD0iIzFEMUUzMCIvPjxjaXJjbGUgY3g9IjE1MCIgY3k9IjMwMCIgcj0iMzAiIGZpbGw9IiM2QTRCQkUiLz48Y2lyY2xlIGN4PSIxNTAiIGN5PSIzODAiIHI9IjMwIiBmaWxsPSIjMkEwQTRBIi8+PGNpcmNsZSBjeD0iMTUwIiBjeT0iNDYwIiByPSIzMCIgZmlsbD0iIzJBMEE0QSIvPjxyZWN0IHg9IjIxMCIgeT0iMjkwIiB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iIzQ4M0Q3MCIvPjxyZWN0IHg9IjIxMCIgeT0iMzcwIiB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iIzQ4M0Q3MCIvPjxyZWN0IHg9IjIxMCIgeT0iNDUwIiB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iIzQ4M0Q3MCIvPjxyZWN0IHg9IjYwMCIgeT0iMjkwIiB3aWR0aD0iNDUwIiBoZWlnaHQ9IjIwMCIgcng9IjQiIGZpbGw9IiMyQTBBNEEiLz48cmVjdCB4PSI2NTAiIHk9IjMyMCIgd2lkdGg9IjM1MCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiM2QTRCQkUiLz48cmVjdCB4PSI2NTAiIHk9IjM2MCIgd2lkdGg9IjI1MCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiM0ODNENzAiLz48cmVjdCB4PSI2NTAiIHk9IjQwMCIgd2lkdGg9IjMwMCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiM0ODNENzAiLz48cmVjdCB4PSI2NTAiIHk9IjQ0MCIgd2lkdGg9IjIwMCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiM0ODNENzAiLz48L3N2Zz4=" 
                  alt="YouTube Toolkit App Interface" 
                  className="w-full h-auto rounded-xl"
                />
              </div>
            </div>
          </div>

          {/* Floating elements for visual flair */}
          <div className="absolute -top-5 -right-5 animate-pulse">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl rotate-12 shadow-xl"></div>
          </div>
          <div className="absolute -bottom-5 -left-5 animate-pulse delay-300">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full shadow-xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
