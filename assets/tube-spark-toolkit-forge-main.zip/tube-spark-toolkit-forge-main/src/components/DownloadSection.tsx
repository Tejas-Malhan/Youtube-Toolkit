
import { Button } from "@/components/ui/button";
import { Download, CheckCircle } from "lucide-react";

const DownloadSection = () => {
  return (
    <section id="download" className="py-20 px-6">
      <div className="container mx-auto text-center">
        <h2 className="text-4xl font-bold text-white mb-8">Get Started Today</h2>
        <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
          Download YouTube Toolkit now and enjoy a faster, more efficient workflow for all your YouTube content needs.
        </p>

        <div className="max-w-3xl mx-auto bg-gradient-to-r from-gray-800/50 to-gray-900/50 backdrop-blur-lg rounded-3xl p-8 border border-white/10 shadow-2xl">
          <h3 className="text-2xl font-bold text-white mb-6">Choose Your Platform</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-black/40 p-6 rounded-xl border border-white/10 flex flex-col">
              <h4 className="text-xl font-bold text-white mb-4">Windows</h4>
              <p className="text-gray-300 mb-4">For Windows 10 and above</p>
              <ul className="text-gray-300 text-left space-y-2 mb-6">
                <li className="flex items-center"><CheckCircle className="text-green-500 mr-2 h-5 w-5" /> 64-bit Windows 10/11</li>
                <li className="flex items-center"><CheckCircle className="text-green-500 mr-2 h-5 w-5" /> 4GB RAM minimum</li>
                <li className="flex items-center"><CheckCircle className="text-green-500 mr-2 h-5 w-5" /> 500MB free space</li>
              </ul>
              <Button size="lg" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 mt-auto">
                <Download className="mr-2 h-5 w-5" /> Download for Windows
              </Button>
            </div>
            
            <div className="bg-black/40 p-6 rounded-xl border border-white/10 flex flex-col opacity-70">
              <h4 className="text-xl font-bold text-white mb-4">macOS</h4>
              <p className="text-gray-300 mb-4">For macOS 11 (Big Sur) and above</p>
              <ul className="text-gray-300 text-left space-y-2 mb-6">
                <li className="flex items-center"><CheckCircle className="text-green-500 mr-2 h-5 w-5" /> Intel or Apple Silicon</li>
                <li className="flex items-center"><CheckCircle className="text-green-500 mr-2 h-5 w-5" /> 4GB RAM minimum</li>
                <li className="flex items-center"><CheckCircle className="text-green-500 mr-2 h-5 w-5" /> 500MB free space</li>
              </ul>
              <Button size="lg" disabled className="bg-gradient-to-r from-purple-500/50 to-pink-500/50 cursor-not-allowed mt-auto">
                <Download className="mr-2 h-5 w-5" /> Coming Soon
              </Button>
            </div>
          </div>

          <p className="text-gray-400 mt-6">Open source software. Free to use and modify under the MIT license.</p>
        </div>
      </div>
    </section>
  );
};

export default DownloadSection;
