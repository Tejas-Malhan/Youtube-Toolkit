
import { Card, CardContent } from "@/components/ui/card";
import { Download, FileText, ListVideo, Music, Code } from "lucide-react";

const FeatureSection = () => {
  return (
    <section id="features" className="py-20 px-6 bg-black/30">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-white text-center mb-12">Powerful Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <FeatureCard 
            icon={Music}
            title="YouTube Song Downloader" 
            description="Extract and download high-quality audio from any YouTube video in MP3 format. Perfect for creating music libraries." 
            gradient="from-blue-500 to-purple-500" 
          />
          <FeatureCard 
            icon={FileText}
            title="Metadata Extractor" 
            description="Extract titles, descriptions, tags, and other metadata from videos to help optimize your own content." 
            gradient="from-purple-500 to-pink-500" 
          />
          <FeatureCard 
            icon={ListVideo}
            title="Playlist Downloader" 
            description="Download entire playlists with a single click. Save time and organize your collections efficiently." 
            gradient="from-red-500 to-orange-500" 
          />
          <FeatureCard 
            icon={Download}
            title="Video Downloader" 
            description="Download videos in multiple quality options from 360p to 4K. Choose the format that suits your needs." 
            gradient="from-green-500 to-teal-500" 
          />
        </div>
      </div>
    </section>
  );
};

// Feature Card Component
const FeatureCard = ({ icon: Icon, title, description, gradient }) => {
  return (
    <Card className="bg-black/40 border border-white/10 overflow-hidden">
      <CardContent className="p-6">
        <div className={`h-2 bg-gradient-to-r ${gradient} rounded-full mb-6`}></div>
        <div className="flex items-center mb-4">
          <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${gradient} flex items-center justify-center mr-3`}>
            <Icon className="text-white h-5 w-5" />
          </div>
          <h3 className="text-xl font-bold text-white">{title}</h3>
        </div>
        <p className="text-gray-300">{description}</p>
      </CardContent>
    </Card>
  );
};

export default FeatureSection;
