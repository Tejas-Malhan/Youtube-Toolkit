
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, DownloadCloud } from "lucide-react";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="fixed top-0 w-full z-50 bg-black/20 backdrop-blur-lg border-b border-white/10">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <img src="/lovable-uploads/2352d30d-031f-4169-8a5d-c9c725668489.png" alt="YouTube Toolkit Logo" className="w-full h-full" />
            </div>
            <span className="text-white font-bold text-xl">YouTube Toolkit</span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-gray-300 hover:text-white transition-colors">Features</a>
            <a href="#download" className="text-gray-300 hover:text-white transition-colors">Download</a>
            <a href="#faq" className="text-gray-300 hover:text-white transition-colors">FAQ</a>
            <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              <DownloadCloud className="mr-2 h-4 w-4" /> Download Now
            </Button>
          </div>
          
          {/* Mobile Menu Button - simplified for this version */}
          <Button variant="ghost" className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X /> : <Menu />}
          </Button>
        </div>
        
        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden py-4 space-y-4">
            <a href="#features" className="block text-gray-300 hover:text-white transition-colors py-2">Features</a>
            <a href="#download" className="block text-gray-300 hover:text-white transition-colors py-2">Download</a>
            <a href="#faq" className="block text-gray-300 hover:text-white transition-colors py-2">FAQ</a>
            <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              <DownloadCloud className="mr-2 h-4 w-4" /> Download Now
            </Button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navigation;
