
import { useState } from "react";

const FaqSection = () => {
  return (
    <section id="faq" className="py-20 px-6 bg-black/30">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-white text-center mb-12">Frequently Asked Questions</h2>
        
        <div className="max-w-3xl mx-auto space-y-6">
          <FaqItem 
            question="Is YouTube Toolkit free to use?" 
            answer="Yes, YouTube Toolkit is completely free and open-source. You can use it without any limitations and even modify the code if you need custom features." 
          />
          <FaqItem 
            question="Is it safe to use with my YouTube account?" 
            answer="Yes, YouTube Toolkit is designed to be safe and secure. The open-source nature means the code can be inspected by anyone to verify its safety. It doesn't store your credentials or personal information." 
          />
          <FaqItem 
            question="When will the Mac version be available?" 
            answer="We're actively working on the Mac version and expect to release it soon. Follow our GitHub repository for updates on the release timeline." 
          />
          <FaqItem 
            question="Does YouTube Toolkit work with private or age-restricted videos?" 
            answer="YouTube Toolkit works with most public videos. Some private or age-restricted content may require you to be logged in to your YouTube account." 
          />
          <FaqItem 
            question="How can I report a bug or request a feature?" 
            answer="Since YouTube Toolkit is open-source, you can submit issues or feature requests directly on our GitHub repository. We welcome contributions from the community." 
          />
        </div>
      </div>
    </section>
  );
};

// FAQ Item Component
const FaqItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-black/40 border border-white/10 rounded-xl overflow-hidden">
      <button 
        className="w-full text-left p-6 focus:outline-none flex justify-between items-center"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className="text-xl font-bold text-white">{question}</h3>
        <span className={`text-white text-2xl transition-transform ${isOpen ? 'rotate-45' : ''}`}>+</span>
      </button>
      {isOpen && (
        <div className="px-6 pb-6">
          <p className="text-gray-300">{answer}</p>
        </div>
      )}
    </div>
  );
};

export default FaqSection;
