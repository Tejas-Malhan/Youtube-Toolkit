
import { Github } from "lucide-react";

const FooterSection = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-12 px-6 bg-black/40 border-t border-white/10">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-2 mb-6 md:mb-0">
            <div className="w-8 h-8 flex items-center justify-center">
              <img src="/lovable-uploads/2352d30d-031f-4169-8a5d-c9c725668489.png" alt="YouTube Toolkit Logo" className="w-full h-full" />
            </div>
            <span className="text-white font-bold text-xl">YouTube Toolkit</span>
          </div>
          
          <div className="flex items-center space-x-6 mb-6 md:mb-0">
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-white hover:text-purple-400 transition-colors flex items-center"
            >
              <Github className="mr-2 h-5 w-5" /> View on GitHub
            </a>
          </div>
          
          <div className="text-gray-400">
            © {currentYear} YouTube Toolkit. Open Source.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FooterSection;
